require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname)));

// ============================================================
//  LLM 配置 — 支持多种后端
// ============================================================

// ⚠️ API Key 必须通过 .env 文件配置，禁止硬编码在代码中
const LLM_BASE_URL = process.env.LLM_BASE_URL || 'https://api.deepseek.com';
const LLM_API_KEY = process.env.LLM_API_KEY || '';
const LLM_MODEL = process.env.LLM_MODEL || 'deepseek-chat';

// ============================================================
//  中间件：用户识别
// ============================================================

function requireUserId(req, res, next) {
  const userId = req.headers['x-user-id'] || req.body?.userId;
  if (!userId) {
    return res.status(400).json({ error: '缺少用户标识 (x-user-id)' });
  }
  // 确保用户存在
  db.upsertUser(userId);
  req.userId = userId;
  next();
}

// ============================================================
//  苏格拉底式系统 Prompt 架构
// ============================================================

function buildSystemPrompt(phase, turnCount, conversationHistory) {
  const phaseConfig = getPhaseConfig(phase);

  const userMessages = conversationHistory.filter(m => m.role === 'user').map(m => m.content);
  const stancesSummary = userMessages.length > 0
    ? `用户已表达的关键立场：\n${userMessages.map((m, i) => `${i + 1}. "${m.substring(0, 100)}"`).join('\n')}`
    : '用户尚未表达立场。';

  return `你是"棱镜"——一个永远不给你答案的思维伙伴。

## 你的身份
你不是顾问，不是导师，不是心理医生。
你是一面会主动调整角度的镜子，帮用户看到自己看不见的思考盲区。

## 当前对话状态
- 当前阶段：${phaseConfig.name}
- 阶段说明：${phaseConfig.description}
- 对话轮数：第 ${turnCount} 轮
- ${stancesSummary}

## 阶段追问策略
${phaseConfig.strategy}

## 认知偏差镜像策略
当你在用户的话语中检测到以下偏差信号时，不要直接标注偏差名称，而是构造"镜像问题"让用户自己感受到逻辑断裂：

| 偏差 | 信号词 | 镜像策略 |
|------|--------|---------|
| 沉没成本 | "已经投入了""不甘心""都这么久了""舍不得" | 假设过去投入全部清零，问用户还会做同样选择吗 |
| 确认偏误 | "肯定""一定是""绝对""显然"，只列支持理由 | 要求用户为另一个选项做最有力的辩护 |
| 损失厌恶 | "怕失去""不想冒险""万一亏了" | 指出不选择本身也有代价，问不选的后果 |
| 可得性偏差 | 用最近的/身边的事件做判断 | 把时间和空间尺度拉大，问是否还这么想 |
| 现状偏见 | "维持""将就""习惯""算了""稳定" | 假设现状不存在，问是否会主动选择创造它 |

## 硬性约束（必须严格遵守）
1. **永远不给建议、不给结论、不说"我认为你应该..."**——只问问题
2. 每个回应必须包含至少一个追问，且追问必须是开放式的
3. 追问必须基于用户上一轮的具体用词和情境，禁止使用通用模板
4. 禁止"这是一个好问题""你说得对""我理解"等空洞肯定——直接进入追问
5. 禁止是/否问题（如"你考虑过X吗？"），改为开放式（"X对你意味着什么？"）
6. 当检测到认知偏差时，不直接标注名称，而是构造镜像问题
7. 每个回应长度控制在2-5句话，不要长篇大论
8. 如果连续追问结构相似，必须切换追问方式和角度

## 节奏控制
- 立场澄清阶段：温和、好奇，像在认真听朋友说话
- Pre-Mortem阶段：加压、紧迫，逼用户想象最坏结果
- 盲区探测阶段：锐利、精准，一针见血但不攻击
- 未来回望阶段：温暖、抽离，拉长时间尺度

## 阶段切换判断
当你认为用户在当前阶段的思考已经足够深入时，在回应末尾加上一行：
[PHASE_COMPLETE]
这会触发系统进入下一阶段。不要轻易触发——确保用户真的想深入了再切换。

如果当前是最后一个阶段（未来回望）且用户已经给出了未来视角，在回应末尾加上：
[CONVERSATION_COMPLETE]`;
}

function getPhaseConfig(phase) {
  const configs = {
    define: {
      name: '定义决策',
      description: '用户刚刚说出正在纠结的决定，需要帮他说清楚"到底在纠结什么"',
      strategy: `帮用户厘清决策的本质。关键追问方向：
- "该不该"背后，是不是已经有一个倾向被什么东西拦着？
- 这个决定的核心矛盾是什么？（安全vs自由？稳定vs成长？）
- 用户说出的"决定"是否是真正的决定？有时表面的决定掩盖了更深层的纠结
只用1轮就进入下一阶段。`
    },
    stance: {
      name: '立场澄清',
      description: '帮用户把支持和反对的理由都说清楚',
      strategy: `逐层深挖用户的立场。关键追问方向：
- 第1轮：推动改变的力量是什么？最核心的那个推力？
- 第2轮：如果不改变，维持现状，最坏会怎样？
- 第3轮：如果改变，最坏会怎样？然后问：如果一切顺利，改变之后最吸引你的画面是什么？
注意：不要让用户只说一面，要逼他看到硬币的两面。
3轮后进入下一阶段。`
    },
    premortem: {
      name: 'Pre-Mortem',
      description: '假设决策已经失败，逼用户想象失败的原因',
      strategy: `这是最关键的阶段——大多数人只愿意想好结果，不愿意想坏结果。关键追问方向：
- 第1轮：假设你选择了改变，3年后发现这是一个灾难——最可能的原因是什么？
- 第2轮：假设你选择了不变，3年后同样后悔——最可能的原因是什么？
追问要具体：不要问"可能会出什么问题"，要问"最可能让你后悔的那个具体原因是什么"
2轮后进入下一阶段。`
    },
    blindspot: {
      name: '盲区探测',
      description: '检测认知偏差，用镜像问题让用户自己发现逻辑断裂',
      strategy: `回顾用户之前所有回答，检测认知偏差信号。关键追问方向：
- 第1轮：基于检测到的偏差构造镜像问题。如果检测到多个偏差，选最显著的那个。如果没有明显偏差，问："如果两个选项都不选呢？有没有第三种可能？"
- 第2轮：不管前一轮结果如何，最后一个问题必须是："想象10年后的你，回看今天这个决定——那个未来的你，最希望你考虑的是什么？"
2轮后进入下一阶段。`
    },
    future: {
      name: '未来回望',
      description: '拉长时间尺度，帮用户跳出当下的情绪',
      strategy: `这是收尾阶段。用户的思考已经足够深入。关键方向：
- 确认用户是否感觉"想得更清楚了"
- 告诉用户"你不需要现在就做决定，但你需要记住现在的自己是怎么想的"
- 暗示接下来会生成决策快照
1轮后结束对话。`
    }
  };
  return configs[phase] || configs.define;
}

// ============================================================
//  API 路由
// ============================================================

// --- LLM 代理（前端不再直连 API，Key 安全） ---
app.post('/api/chat', requireUserId, async (req, res) => {
  const { messages, phase, turnCount, conversationId } = req.body;

  if (!LLM_API_KEY) {
    return res.status(500).json({ error: '未配置 LLM_API_KEY，请在 .env 文件中设置' });
  }

  const systemPrompt = buildSystemPrompt(phase, turnCount, messages);

  const apiMessages = [
    { role: 'system', content: systemPrompt },
    ...messages.map(m => ({ role: m.role, content: m.content }))
  ];

  // 记录消息发送事件
  db.recordEvent({
    userId: req.userId,
    type: 'message_send',
    conversationId,
    data: { phase, turnCount, role: messages[messages.length - 1]?.role }
  });

  try {
    const response = await fetch(`${LLM_BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LLM_API_KEY}`
      },
      body: JSON.stringify({
        model: LLM_MODEL,
        messages: apiMessages,
        temperature: 0.7,
        max_tokens: 500,
        top_p: 0.9,
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error('LLM API Error:', response.status, errText);
      return res.status(response.status).json({ error: `LLM API 返回错误: ${response.status}` });
    }

    const data = await response.json();
    let content = data.choices[0].message.content.trim();

    let phaseComplete = false;
    let conversationComplete = false;

    if (content.includes('[CONVERSATION_COMPLETE]')) {
      conversationComplete = true;
      content = content.replace('[CONVERSATION_COMPLETE]', '').trim();
    }
    if (content.includes('[PHASE_COMPLETE]')) {
      phaseComplete = true;
      content = content.replace('[PHASE_COMPLETE]', '').trim();
    }

    res.json({
      content,
      phaseComplete,
      conversationComplete
    });

  } catch (err) {
    console.error('LLM API 请求失败:', err);
    res.status(500).json({ error: 'LLM API 请求失败，请检查网络和配置' });
  }
});

// --- 快照生成（LLM 提取结构化信息） ---
app.post('/api/snapshot', requireUserId, async (req, res) => {
  if (!LLM_API_KEY) {
    return res.status(500).json({ error: '未配置 LLM_API_KEY' });
  }

  const { messages } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: '缺少对话消息' });
  }

  const extractPrompt = `请从以下对话中提取决策快照信息，以 JSON 格式返回。不要包含任何其他文字。

对话内容：
${messages.map(m => `${m.role === 'user' ? '用户' : '棱镜'}：${m.content}`).join('\n')}

请返回如下 JSON：
{
  "title": "决策的简短标题（15字以内）",
  "type": "职业/关系/城市/投资/教育/人生",
  "stances": "用户的核心立场摘要（2-3句话）",
  "premortem_change": "选择改变后的灾难预判",
  "premortem_stay": "选择不变后的灾难预判",
  "blindspots": "识别到的认知盲区（1-2句话）",
  "future_perspective": "10年后的视角",
  "confidence": 7
}`;

  try {
    const response = await fetch(`${LLM_BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${LLM_API_KEY}`
      },
      body: JSON.stringify({
        model: LLM_MODEL,
        messages: [{ role: 'user', content: extractPrompt }],
        temperature: 0.3,
        max_tokens: 500,
      })
    });

    if (!response.ok) {
      return res.status(response.status).json({ error: `LLM API 返回错误: ${response.status}` });
    }

    const data = await response.json();
    let content = data.choices[0].message.content.trim();
    const jsonMatch = content.match(/\{[\s\S]*\}/);

    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return res.json(parsed);
    }

    return res.status(500).json({ error: '无法解析 LLM 返回的快照数据' });
  } catch (err) {
    console.error('快照生成失败:', err);
    res.status(500).json({ error: '快照生成失败' });
  }
});

// --- 对话 CRUD ---
app.post('/api/conversations', requireUserId, (req, res) => {
  const conversation = {
    ...req.body,
    userId: req.userId,
  };
  delete conversation.userId; // userId 已在外层设置
  const saved = db.saveConversation({ ...req.body, userId: req.userId });
  res.json(saved);
});

app.get('/api/conversations', requireUserId, (req, res) => {
  const conversations = db.getConversationsByUser(req.userId);
  // 不返回完整消息列表以减小体积，只返回元数据
  const lite = conversations.map(c => ({
    id: c.id,
    title: c.title,
    type: c.type,
    status: c.status,
    confidence: c.confidence,
    phase: c.phase,
    totalTurns: c.totalTurns,
    createdAt: c.createdAt,
    updatedAt: c.updatedAt,
    calibrationDate: c.calibrationDate,
  }));
  res.json(lite);
});

app.get('/api/conversations/:id', requireUserId, (req, res) => {
  const conv = db.getConversation(req.params.id);
  if (!conv || conv.userId !== req.userId) {
    return res.status(404).json({ error: '对话不存在' });
  }
  res.json(conv);
});

app.delete('/api/conversations/:id', requireUserId, (req, res) => {
  const conv = db.getConversation(req.params.id);
  if (!conv || conv.userId !== req.userId) {
    return res.status(404).json({ error: '对话不存在' });
  }
  db.deleteConversation(req.params.id);
  res.json({ ok: true });
});

// --- 埋点事件 ---
app.post('/api/events', requireUserId, (req, res) => {
  const { type, conversationId, data } = req.body;
  if (!type) {
    return res.status(400).json({ error: '缺少事件类型' });
  }
  db.recordEvent({
    userId: req.userId,
    type,
    conversationId,
    data,
  });
  res.json({ ok: true });
});

// --- 用户信息 ---
app.get('/api/user', requireUserId, (req, res) => {
  const user = db.getUser(req.userId);
  res.json(user);
});

// --- 管理统计 ---
app.get('/api/stats', (req, res) => {
  res.json(db.getStats());
});

// --- 健康检查 ---
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    llm: LLM_API_KEY ? 'configured' : 'not configured',
    model: LLM_MODEL,
    baseUrl: LLM_BASE_URL
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🔮 思维棱镜原型服务器已启动`);
  console.log(`   地址: http://localhost:${PORT}`);
  console.log(`   LLM:  ${LLM_MODEL} @ ${LLM_BASE_URL}`);
  if (!LLM_API_KEY) {
    console.log(`\n   ❌ API Key 未配置！请按以下步骤设置：`);
    console.log(`      1. 复制 .env.example 为 .env：cp .env.example .env`);
    console.log(`      2. 在 .env 中填入 LLM_API_KEY=你的密钥`);
    console.log(`      3. 重启服务器\n`);
  } else {
    console.log(`   API:  ✅ 已配置\n`);
  }
});
